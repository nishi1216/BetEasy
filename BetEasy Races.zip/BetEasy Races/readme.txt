=== BetEasy Plugin ===
Contributors: user, user, user
Tags: tag, tag, tag
Donate link: http://example.com/
Requires at least: 4.0
Tested up to: 5.0.3
Requires PHP: 5.6
Stable tag: 1.1
 
== Description ==
This Custom Plugin fetch data from JSON and display on WordPress page/post with the shortcode [BetEasy_races].
 

== Installation ==
1. Upload "BetEasy Races" to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
 

== Frequently Asked Questions ==
= How to display Races on Page or Post?
Answer : Create a new Page/Post and use shortcode [BetEasy_races] to fetch the result from Json. 



== Screenshots ==
1. The screenshot description corresponds to screenshot.png.


== Changelog ==
= 0.2 =
* A change since the previous version.
* Another change.

= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
Upgrade notices describe the reason a user should upgrade

= 0.1 =
This version fixes a security related bug. Upgrade immediately.