<?php
/*
Plugin Name: BetEasy Races

Description: Plugin to fetch data from JSON and display on WordPress page/post with the shortcode [BetEasy_races].
Version: 1.0
Author: Nishi Bhavsar

*/

/* block direct requests */

defined('ABSPATH') OR exit;

add_action('admin_menu', 'test_plugin_setup_menu');
 
function test_plugin_setup_menu(){
        add_menu_page( 'Test Plugin Page', 'BetEasy Races', 'manage_options', 'test-plugin', 'test_init' );
}
 
function test_init(){
 ?>
<div>
  <?php screen_icon(); ?>
  <h1>BetEasy Races Plugin</h1>

  <?php settings_fields( 'myplugin_options_group' ); ?>
  <h3>How to use this plugin?</h3>
  <p>Create a new Page/Post and use shortcode [BetEasy_races] to fetch the result. </p>
 
  
  </div>

        <?php 
}

 add_shortcode("BetEasy_races", "my_shortcode_function");

function my_shortcode_function() {


$json=file_get_contents("https://s3-ap-southeast-2.amazonaws.com/bet-easy-code-challenge/next-to-jump");
$data =  json_decode($json);


    if ($data === null && json_last_error() !== JSON_ERROR_NONE ) { //Error handling when incorrect data

      echo "Incorrect Data.."; 

    } else { //JSON cointains valid data
    ?>
    <div class="BetEasy">
    	<div class="logos">
    		<div class="main-logo">
    			<a href="https://beteasy.com.au"><svg class="Icon__icon--YFXFc NavBar__betEasyIcon--2P07j" viewBox="0 0 274 158"><defs><linearGradient id="logo-gradient" x1="151.5867" x2="270.7755" y1="123.8671" y2="4.6783" gradientTransform="matrix(1 0 0 1 -1.6539 0)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#23b4b7"></stop><stop offset=".8882" stop-color="#23b4b7" stop-opacity="0"></stop></linearGradient></defs><path d="M0 115.56V43.89h18.17c9.96 0 17.14 5.53 17.14 16.28v5.02c0 4.92-2.46 10.55-7.08 12.7 5.13 2.46 7.7 6.96 7.7 13.62v6.14c0 10.75-6.57 17.92-17.55 17.92H0zm12.32-41.67h3.7c4.52 0 6.98-3.17 6.98-7.37v-4.71c0-4.2-2.36-7.58-6.98-7.58h-3.7v19.66zm0 31.33h4.41c4.52 0 6.98-3.07 6.98-7.99V91.3c0-4.81-2.57-7.68-7.19-7.68h-4.21v21.6z"></path><path d="M39.48 115.56V43.89H71.3v10.65H51.8v17.41h12.52V82.6H51.8v22.32h20.22v10.65H39.48z"></path><path d="M98.28 115.56H86.06V54.53H74.97V43.89h34.39v10.65H98.28v61.02z"></path><path fill="url(#logo-gradient)" d="M194.8 158c-43.67 0-79.2-35.44-79.2-79s35.53-79 79.2-79S274 35.44 274 79s-35.53 79-79.2 79zm0-145.33c-36.67 0-66.5 29.76-66.5 66.33s29.83 66.33 66.5 66.33 66.5-29.76 66.5-66.33-29.83-66.33-66.5-66.33z"></path><path d="M144.76 109.09V48.91h20.81v6.96h-12.81v17.2h8.51v6.88h-8.51v22.18h13.16v6.96h-21.16z"></path><path d="M193.51 109.09h-8.08l-1.2-11.52h-6.88l-1.29 11.52h-7.48l7.31-60.19h10.4l7.22 60.19zm-12.55-43.16l-2.92 25.54h5.59l-2.67-25.54z"></path><path d="M217.5 69.03h-7.4v-9.54c0-2.92-1.12-4.38-3.44-4.38-2.06 0-3.27 1.63-3.27 3.96v5.42c0 3.61 1.2 6.53 3.53 8.77l5.33 5.07c3.96 3.7 5.93 8.68 5.93 15.13V98c0 6.96-4.39 11.69-11.52 11.69-7.14 0-11.35-4.39-11.35-11.26V86.82h7.48v11.61c0 2.67 1.29 4.39 3.7 4.39 2.32 0 3.61-1.63 3.61-4.13v-5.5c0-3.96-1.2-6.96-3.53-9.11l-4.99-4.64c-4.21-3.87-6.28-8.86-6.28-14.87V59.5c0-6.88 4.47-11.18 11.26-11.18 7.14 0 10.92 4.3 10.92 10.83v9.88z"></path><path d="M235.72 109.09h-8V84.42l-9.11-35.51h8.68l4.47 22.87 4.9-22.87h8.17l-9.11 35.25v24.93z"></path></svg></a> </div>

    		<div class="races"> <svg class="Icon__icon--YFXFc NavBarLink__icon--25zi4" viewBox="0 0 25 25"><path d="M12.5 25C5.61 25 0 19.39 0 12.5S5.61 0 12.5 0 25 5.61 25 12.5 19.39 25 12.5 25zm0-24.07C6.12.93.93 6.12.93 12.5S6.12 24.07 12.5 24.07s11.57-5.19 11.57-11.57S18.88.93 12.5.93zm9.12 15.18c-.02.3-.12.58-.2.82-.02.07-.05.14-.07.21-.06.19-.19.33-.36.41-.17.07-.37.06-.55-.03-.28-.14-.45-.13-.69.07-.29.23-.53.33-.74.33-.29 0-.54-.19-.82-.48-.18-.19-.34-.4-.49-.59-.09-.11-.18-.23-.27-.34-.79-.18-1.69-.42-2.55-.92h-.06-.04l-.82-.03c-.51-.02-1.02-.04-1.54-.07-.2-.01-.38-.07-.54-.12l-.05-.02c-1.56-.49-2.28-1.58-2.27-3.44 0-.11.01-.22.02-.33l.01-.12a.47.47 0 0 1 .5-.43c.25.02.45.24.43.5l-.01.14c-.01.08-.02.16-.02.25-.01 1.45.46 2.19 1.62 2.56l.06.02c.12.04.23.07.31.08.51.03 1.02.05 1.52.07l.83.03c.15 0 .32.01.48.11.78.45 1.63.68 2.37.84.23.05.39.21.47.3.1.12.19.24.29.36.15.19.29.37.44.53.07.07.12.13.16.16.03-.02.08-.05.14-.1.44-.35.9-.45 1.39-.29.07-.19.12-.36.13-.52.02-.33-.01-.66-.04-1.02l-.02-.17c-.12-.12-.23-.22-.34-.33-.24-.23-.49-.46-.7-.74-.63-.83-1.34-1.7-2.17-2.43-.32-.28-.7-.69-.75-1.32-.01-.02-.07-.11-.09-.14-.16-.23-.3-.45-.47-.64-.27-.31-.46-.54-.64-.76-.21-.26-.41-.5-.71-.84a.468.468 0 0 1-.02-.6c.6-.76.82-1.76.97-2.42.04-.2.08-.37.12-.51.07-.25.33-.39.57-.31.25.07.39.33.31.57-.03.12-.07.28-.11.45-.15.66-.36 1.62-.92 2.47.19.22.34.4.49.59.18.22.36.44.62.74.2.23.37.48.54.73.11.16.23.35.25.58.02.24.15.45.44.7.89.78 1.63 1.7 2.29 2.56.17.22.38.42.6.62.12.11.24.22.35.34.09.1.25.26.27.49l.02.27c.05.38.08.77.06 1.16zm-7.79-9.25a.452.452 0 0 1-.05-.65c.23-.28.43-.77.57-1.32l-.09.06c-.16.11-.3.21-.43.33-.4.35-.71.65-.83 1.07a.46.46 0 0 1-.42.34l-.1.01c-.1.01-.2.01-.3.01-.73-.02-1.44.15-2.14.5a11.33 11.33 0 0 0-3.81 3.13c-1.27 1.61-2.14 3.49-2.65 5.77l-.11.46c-.05.21-.24.36-.45.36-.03 0-.07 0-.1-.01a.463.463 0 0 1-.35-.55l.1-.46c.55-2.41 1.47-4.42 2.83-6.14 1.14-1.44 2.53-2.58 4.12-3.38.84-.42 1.7-.62 2.58-.6h.02c.24-.55.67-.92.99-1.2.17-.15.34-.27.51-.39l.11-.08c.33-.24.6-.43.74-.71.1-.21.34-.31.56-.24l.04.01c.21.07.38.29.35.51-.09.67-.36 2.32-1.04 3.12a.46.46 0 0 1-.65.05zm-3.31 8.09c.26-.01.47.2.47.45.01.53.15 1.08.47 1.78.11.24.23.47.37.71.06.11.12.22.17.32.17.32.34.63.51.94.39.72.79 1.45 1.14 2.21.11.24.21.47.31.72.1.24-.02.51-.25.6-.06.02-.12.04-.18.04-.18 0-.35-.11-.43-.29-.09-.23-.19-.45-.3-.68-.34-.73-.73-1.46-1.11-2.16-.17-.32-.34-.63-.51-.95-.05-.1-.11-.21-.17-.31-.14-.25-.28-.51-.4-.78-.36-.82-.53-1.48-.55-2.14.01-.25.21-.46.46-.46z"></path></svg>
    			<span>Racing</span>

    		</div>
    	</div>
    	<div class="NextToJump__title--20zq8">Next to Jump</div>

     <?php   // Cycle through the array
        foreach ($data->result as $idx => $stand) {
 
            // Format Date

             	 $seconds = strtotime($stand->AdvertisedStartTime) - time();

        				$days = floor($seconds / 86400);
        				$seconds %= 86400;

        				$hours = floor($seconds / 3600);
        				$seconds %= 3600;

        				$minutes = floor($seconds / 60);
        				$seconds %= 60;
?>
	
           <div class="NextToJump__raceEvent--bfMON">
           		<div class="NextToJump__iconWrapper--1yG60">
           			<svg class="Icon__icon--YFXFc NextToJump__icon--2q5Mk" viewBox="0 0 32 32"><path d="M17.72,28.24a.54.54,0,0,1-.48-.32c-.08-.24-.24-.56-.32-.8-.4-.88-.88-1.76-1.28-2.65-.24-.4-.4-.72-.64-1.12l-.24-.4-.48-1a7.06,7.06,0,0,1-.64-2.65.55.55,0,0,1,.56-.56.6.6,0,0,1,.56.56,5.09,5.09,0,0,0,.56,2.17c.16.32.24.56.4.88l.24.4c.16.4.4.72.56,1.12.48.88,1,1.76,1.44,2.73a9.41,9.41,0,0,1,.4.88c.08.32,0,.64-.32.72Zm6.58-5.86a1.53,1.53,0,0,1-1-.56,4.41,4.41,0,0,1-.56-.72c-.08-.16-.24-.24-.32-.4a11.41,11.41,0,0,1-3.13-1.12l-1.12-.16c-.56,0-1.2-.08-1.85-.08a1.51,1.51,0,0,1-.64-.16c-2-.56-2.81-2-2.81-4.25v-.56a.52.52,0,0,1,1,.08v.48c0,1.76.56,2.65,2,3.13a1.07,1.07,0,0,0,.4.08c.56,0,1.2.08,1.85.08l1,.08a.76.76,0,0,1,.56.16,8.18,8.18,0,0,0,2.89,1,1,1,0,0,1,.56.4,1.75,1.75,0,0,0,.32.4c.16.24.32.4.48.64l.16.16.16-.16A1.61,1.61,0,0,1,26,20.54a1.89,1.89,0,0,0,.16-.64,6.07,6.07,0,0,0-.08-1.2v-.24l-.4-.4a4.2,4.2,0,0,1-.8-.88,22.67,22.67,0,0,0-2.65-3,2.28,2.28,0,0,1-.88-1.68l-.08-.16a2.5,2.5,0,0,0-.56-.72c-.32-.4-.56-.64-.72-.88s-.48-.56-.8-1a.6.6,0,0,1,0-.72,6.82,6.82,0,0,0,1.12-3c.08-.24.08-.48.16-.64a.53.53,0,0,1,.64-.4.57.57,0,0,1,.4.72,5.11,5.11,0,0,0-.16.56,9.16,9.16,0,0,1-1,3,4.63,4.63,0,0,1,.64.8c.24.24.4.56.72.88a8.4,8.4,0,0,1,.64.88,1.51,1.51,0,0,1,.32.72,1,1,0,0,0,.48.8,25.35,25.35,0,0,1,2.81,3.13,6.13,6.13,0,0,0,.72.72l.4.4a1,1,0,0,1,.32.56v.32c0,.48.08.88.08,1.44a3.39,3.39,0,0,1-.24,1v.4a.82.82,0,0,1-.4.48.89.89,0,0,1-.64,0,.61.61,0,0,0-.8.08A2.46,2.46,0,0,1,24.29,22.39ZM5,21.1H4.8a.53.53,0,0,1-.4-.64l.16-.56A19.17,19.17,0,0,1,8,12.36a14,14,0,0,1,5-4.17,7.15,7.15,0,0,1,3.13-.72,6,6,0,0,1,1.2-1.52A4.45,4.45,0,0,1,18,5.46l.16-.08A1.88,1.88,0,0,0,19,4.5a.76.76,0,0,1,.8-.32.93.93,0,0,1,.32.8,8.25,8.25,0,0,1-1.2,3.77A.57.57,0,0,1,18,8a4.4,4.4,0,0,0,.64-1.6l-.08.08c-.16.16-.32.24-.48.4a2.86,2.86,0,0,0-1,1.28.51.51,0,0,1-.48.4h-.48a5.94,5.94,0,0,0-2.57.56A14.92,14.92,0,0,0,8.89,13a17.27,17.27,0,0,0-3.21,7.06l-.16.56A.59.59,0,0,1,5,21.1Z"></path>
           			</svg>
           		</div>
           		<div class="NextToJump__eventDetail--CUzdX">
                <div class="NextToJump__venue--1jwWA"><?php echo $stand->Venue->Venue;?></div>
                <div class="NextToJump__race--3JydR">
                    <span><?php echo $stand->EventName; ?></span>
                </div>
              </div><div class="NextToJump__countdown--EG8mR"><span class="Countdown__countdown--4vRpD Countdown__past--1c0Xg"><?php echo $days.'d '. $hours .'h '. $minutes .'m'; ?></span></div></div>

<?php
        
        }
?> </div> <?php
        
    }
} 
//Add styling to reflect the BetEasy Brand 
?>
<style type="text/css">
.logos{
	display: flex;
  justify-content: space-between;
  
}
.main-logo{ padding: 15px 15px; }
.main-logo a {color: #883bc2 !important; }
.main-logo .Icon__icon--YFXFc{
  	width: 100px;
  	height: auto;
  	
}
.races {padding: 15px 0;  }
.races span {
	    display: flex;
      font-size: 15px;
      font-family: Roboto,Arial,Helvetica,sans-serif;
    
}
.races .Icon__icon--YFXFc{
	    width: 35px;
      height: auto;
}
.races {
	    border-left: 1px solid #aaa;
      padding-left: 27px;
      padding-right: 15px;
}

.BetEasy {
	    background-color: #fff;
    border-radius: 4px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    margin-bottom: 6px;
    margin: 0 auto !important;
    max-width: 300px !important;
    border: 1px solid #aaa;
}
	.NextToJump__title--20zq8 {
    background-color: #8935c0;
  
    color: #fff;
    padding: 12px 14px;
    margin: 0 !important;
    font-family: Roboto,Arial,Helvetica,sans-serif;
    font-size: 16px;
    font-weight:900;
    line-height: 1.15;
}
.NextToJump__race--3JydR span {
    color: #afafaf;
}
.NextToJump__raceEvent--bfMON {
    border-top: 1px solid #ebedf5;
    font-size: 12px;
    font-weight: 400;
    font-family: Roboto,Arial,Helvetica,sans-serif;
    padding: 8px 0;
    color:#243a80;
    cursor: pointer;
}
.NextToJump__raceEvent--bfMON:hover {
  background-color: #fbfbfd;
}
.NextToJump__iconWrapper--1yG60{
	    display: inline-block;
    vertical-align: top;
    padding: 10px 10px;
}
.NextToJump__icon--2q5Mk {
    color: #232539;
    height: 32px;
    width: 32px;
}
.Icon__icon--YFXFc {
    fill: currentColor;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    height: 24px;
    vertical-align: top;
    width: 24px;
}
.NextToJump__countdown--EG8mR{ float: right;padding-right: 15px; }
.NextToJump__eventDetail--CUzdX {
    display: inline-block;max-width: 100px;
}
.NextToJump__eventDetail--CUzdX .NextToJump__venue--1jwWA {
    color: #243a80;
    font-weight: 400;
    font-family: Roboto,Arial,Helvetica,sans-serif;
}
</style>